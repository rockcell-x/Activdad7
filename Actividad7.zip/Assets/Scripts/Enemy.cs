using UnityEngine;

public class Enemy : MonoBehaviour
{
  public float maxHealth = 3f;  // Vida máxima del enemigo
    private float currentHealth;  // Vida actual del enemigo
    private Renderer enemyRenderer; // Renderer del enemigo para cambiar de color

    void Start()
    {
        // Inicializar la vida del enemigo y obtener el Renderer
        currentHealth = maxHealth;
        enemyRenderer = GetComponent<Renderer>();

        // Establecer el color inicial
        UpdateColor();
    }

    // Función pública para aplicar daño al enemigo
    public void TakeDamage(float amount)
    {
        // Reducir la vida del enemigo
        currentHealth -= amount;
        Debug.Log(transform.name + " recibió " + amount + " de daño. Vida restante: " + currentHealth);

        // Actualizar el color del enemigo según su vida
        UpdateColor();

        // Si la vida llega a 0 o menos, el enemigo muere
        if (currentHealth <= 0f)
        {
            Die();
        }
    }

    // Función para actualizar el color del enemigo según su vida
    void UpdateColor()
    {
        if (currentHealth == 3)
        {
            enemyRenderer.material.color = Color.green;  // Verde
        }
        else if (currentHealth == 2)
        {
            enemyRenderer.material.color = Color.yellow; // Amarillo
        }
        else if (currentHealth == 1)
        {
            enemyRenderer.material.color = Color.red;    // Rojo
        }
    }

    // Función para destruir al enemigo cuando su vida llega a 0
    void Die()
    {
        Debug.Log(transform.name + " ha muerto.");
        Destroy(gameObject);  // Destruye el objeto del enemigo
    }
    
}
