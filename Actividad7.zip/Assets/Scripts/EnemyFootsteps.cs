using UnityEngine;

public class EnemyFootsteps : MonoBehaviour
{
     public AudioClip[] footstepSounds; // Array de clips de sonido de pisadas.
    public float footstepInterval = 0.5f; // Intervalo entre cada pisada.
    private AudioSource audioSource;
    private float lastFootstepTime = 0f; // Momento en que sonó la última pisada.

    private EnemyChase enemyMovement; // Script de movimiento del enemigo.

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        enemyMovement = GetComponent<EnemyChase>(); // Asegúrate de que el enemigo tenga un script de movimiento.
    }

    void Update()
    {
      // Verifica si el enemigo se está moviendo.
        if (enemyMovement) // IsMoving() es un ejemplo, depende de cómo controles el movimiento.
        {
            // Si ha pasado suficiente tiempo desde la última pisada, reproduce el sonido.
            if (Time.time > lastFootstepTime + footstepInterval)
            {
                PlayFootstep();
                lastFootstepTime = Time.time; // Actualiza el tiempo de la última pisada.
            }
        }
    }

    // Reproduce un sonido de pisada aleatorio.
    void PlayFootstep()
    {
        if (footstepSounds.Length > 0)
        {
            int randomIndex = Random.Range(0, footstepSounds.Length);
            AudioClip footstepClip = footstepSounds[randomIndex];
            audioSource.PlayOneShot(footstepClip); // Reproduce el sonido.
        }
    }
}
