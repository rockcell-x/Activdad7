using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class DamageVignetteEffect : MonoBehaviour
{
   public Volume globalVolume;  // El volumen global que tiene el Vignette.
    public float maxVignetteIntensity = 0.6f;  // Intensidad máxima de la viñeta.
    private Vignette vignette;  // Componente Vignette del Volume Profile.

    public PlayerHealth playerHealth;  // Referencia a la salud del jugador.
    public float maxHealth = 50f;  // Salud máxima del jugador.

    void Start()
    {
        // Obtener el Vignette del Volume Profile.
        if (globalVolume.profile.TryGet<Vignette>(out vignette))
        {
            vignette.intensity.value = 0f;  // Inicia con el efecto en 0.
        }
        else
        {
            Debug.LogError("No se encontró el componente Vignette en el Volume Profile.");
        }

        // Configurar el valor máximo de salud (puedes personalizar este valor).
        if (playerHealth != null)
        {
            maxHealth = playerHealth.maxHealth;
        }
    }

    void Update()
    {
        // Actualizar el efecto de Vignette basado en la salud actual del jugador.
        float healthPercentage = Mathf.Clamp01(playerHealth.currentHealth / maxHealth);

        // La intensidad del Vignette aumenta cuando la salud disminuye.
        vignette.intensity.value = Mathf.Lerp(maxVignetteIntensity, 0f, healthPercentage);
    }
}
