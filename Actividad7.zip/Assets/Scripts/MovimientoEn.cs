using UnityEngine;

public class MovimientoEn : MonoBehaviour
{
    public Vector3 pointA = new Vector3(11, 8, 13);  // Coordenadas del punto A
    public Vector3 pointB = new Vector3(25, 8, 13);  // Coordenadas del punto B
    public float speed = 2f;  // Velocidad del movimiento

    private float t = 0;      // Valor para la interpolación
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       t += Time.deltaTime * speed;

        // Mover el objeto entre pointA y pointB de manera cíclica
        transform.position = Vector3.Lerp(pointA, pointB, Mathf.PingPong(t, 1));
    }
}
