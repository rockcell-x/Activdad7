using UnityEngine;

public class AttackWeapon : MonoBehaviour
{public Camera playerCamera;  // La cámara del jugador para disparar en la dirección en la que mira
    public float range = 100f;   // Rango máximo del disparo
    public LayerMask hitLayer;   // Capa en la que los objetos pueden ser golpeados (opcional)

    void Update()
    {
        // Detectar si el jugador presiona el botón de disparo (ej. click izquierdo)
        if (Input.GetButtonDown("Fire1"))
        {
            Shoot();
        }
    }

    // Función para manejar el disparo
    void Shoot()
    {
        RaycastHit hit;

        // Lanzar un raycast desde el centro de la cámara hacia adelante
        if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward, out hit, range, hitLayer))
        {
            // Si golpeamos algo, imprimimos información sobre el objeto golpeado
            Debug.Log("Golpeaste: " + hit.transform.name);

            // Puedes añadir lógica aquí para hacer daño a un enemigo u otro comportamiento
            if (hit.transform.CompareTag("Enemy"))
            {
                // Ejemplo: Si golpeas a un enemigo, puedes reducir su vida
                Debug.Log("Has golpeado a un enemigo");
                // Aquí iría la lógica para dañar al enemigo
            }
        }
        if (hit.transform.CompareTag("Enemy"))
{
    // Si golpeas a un enemigo, llamas a la función TakeDamage del enemigo
    Enemy enemy = hit.transform.GetComponent<Enemy>();

    if (enemy != null)
    {
        enemy.TakeDamage(1f);  // Aplica 25 de daño al enemigo (puedes ajustar la cantidad de daño)
    }
}
    }
}
