﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWeaponController : MonoBehaviour
{
    public List<WeaponController> startingWeapons = new List<WeaponController>();

    public Transform weaponParentSocket;
    public Transform defaultWeaponPosition;
    public Transform aimingPosition;

    public int activeWeaponIndex { get; private set; }

    private WeaponController[] weaponSlots = new WeaponController[5];

    public GameObject BloodEffect; // Reference to the blood effect prefab
    public GameObject DustEffect; // Reference to the dust effect prefab

    public int EnemyDamage = 10; // Damage dealt to the enemy

    // Start is called before the first frame update
    void Start()
    {
        activeWeaponIndex = -1;

        foreach (WeaponController startingWeapon in startingWeapons)
        {
            AddWeapon(startingWeapon);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            SwitchWeapon(0);
        }
    }
    public float range = 100f; // Define the range for the raycast

    void Shoot()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, transform.forward, out hit, range))
        {
            if (hit.collider.CompareTag("Enemy"))
            {
                // Si golpeamos un enemigo, mostramos el efecto de sangre.
                Instantiate(BloodEffect, hit.point, Quaternion.LookRotation(hit.normal));

                // Aquí puedes agregar lógica para hacer daño al enemigo
                hit.collider.GetComponent<Enemy>().TakeDamage(EnemyDamage);
            }
            else if (hit.collider.CompareTag("Wall"))
            {
                // Si golpeamos una pared, mostramos el efecto de polvo.
                Instantiate(DustEffect, hit.point, Quaternion.LookRotation(hit.normal));
            }
        }
    }

    private void SwitchWeapon(int p_weaponIndex)
    {
        if (p_weaponIndex != activeWeaponIndex && p_weaponIndex >= 0)
        {
            weaponSlots[p_weaponIndex].gameObject.SetActive(true);
            activeWeaponIndex = p_weaponIndex;
        }
    }

    private void AddWeapon(WeaponController p_weaponPrefab)
    {
        weaponParentSocket.position = defaultWeaponPosition.position;

        //Añadir arma al jugador pero no mostrarla
        for (int i = 0; i<weaponSlots.Length; i++)
        {
            if (weaponSlots[i] == null)
            {
                WeaponController weaponClone = Instantiate(p_weaponPrefab, weaponParentSocket);
                weaponClone.gameObject.SetActive(false);

                weaponSlots[i] = weaponClone;
                return;
            }
        }
    }
}
