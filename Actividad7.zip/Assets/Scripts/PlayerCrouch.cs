using UnityEngine;

public class PlayerCrouch : MonoBehaviour
{
   public CharacterController characterController;  // Referencia al CharacterController del jugador
    public float crouchHeight = 1.0f;                // Altura cuando el jugador se agacha
    public float normalHeight = 2.0f;                // Altura normal del jugador
    public float crouchSpeed = 2.0f;                 // Velocidad al moverse agachado
    public float normalSpeed = 5.0f;                 // Velocidad normal del jugador

    private bool isCrouching = false;                // Estado de si el jugador está agachado o no

    void Update()
    {
        // Detectar si el jugador presiona el botón de agacharse (por defecto "C" en este ejemplo)
        if (Input.GetKeyDown(KeyCode.C))
        {
            ToggleCrouch();
        }
    }

    // Función para alternar el estado de agachado
    void ToggleCrouch()
    {
        if (isCrouching)
        {
            // Volver a la altura y velocidad normal
            characterController.height = normalHeight;
            characterController.center = new Vector3(0, normalHeight / 2, 0); // Ajustar el centro del CharacterController
            GetComponent<PlayerController>().walkSpeed = normalSpeed;       // Restaurar la velocidad normal
            isCrouching = false;
        }
        else
        {
            // Cambiar a la altura y velocidad de agachado
            characterController.height = crouchHeight;
            characterController.center = new Vector3(0, crouchHeight / 2, 0); // Ajustar el centro del CharacterController
            GetComponent<PlayerController>().walkSpeed = crouchSpeed;       // Reducir la velocidad al agacharse
            isCrouching = true;
        }
    }
}
