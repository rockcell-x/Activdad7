using UnityEngine;

public class EnemyChase : MonoBehaviour
{
    public Transform PlayerController;  // Referencia al jugador
    public float detectionRange = 10f;  // Rango en el cual el enemigo empezará a acercarse
    public float moveSpeed = 3f;  // Velocidad del enemigo

    void Update()
    {
        // Calcular la distancia entre el enemigo y el jugador
        float distanceToPlayer = Vector3.Distance(transform.position, PlayerController.position);

        // Si la distancia es menor que el rango de detección, el enemigo se acerca al jugador
        if (distanceToPlayer <= detectionRange)
        {
            // Mover al enemigo hacia el jugador
            MoveTowardsPlayer();
        }
    }

    // Método para mover al enemigo hacia el jugador
    void MoveTowardsPlayer()
    {
        // Direccionar al enemigo hacia el jugador
        Vector3 direction = (PlayerController.position - transform.position).normalized;

        // Mover al enemigo hacia el jugador
        transform.position += direction * moveSpeed * Time.deltaTime;
    }
}