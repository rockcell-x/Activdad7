using System.Collections;
using UnityEngine;

public class SpawnEnemy : MonoBehaviour
{
   public GameObject enemyPrefab;  // El prefab del enemigo a spawnear.
    public Transform[] spawnPoints; // Array de puntos de spawn.
    public float spawnInterval = 5f; // Tiempo entre cada spawn.
    public int maxEnemies = 10;  // Número máximo de enemigos permitidos.

    private int enemyCount = 0;  // Contador de enemigos instanciados.

    void Start()
    {
        // Si no hay prefab asignado o no hay puntos de spawn, mostrar advertencia.
        if (enemyPrefab == null)
        {
            Debug.LogError("Prefab del enemigo no asignado en el spawner.");
        }
        if (spawnPoints.Length == 0)
        {
            Debug.LogError("No hay puntos de spawn asignados.");
        }

        // Inicia el proceso de spawn de enemigos.
        StartCoroutine(SpawnEnemies());
    }

    IEnumerator SpawnEnemies()
    {
        while (true)
        {
            // Espera el intervalo definido antes de spawnear.
            yield return new WaitForSeconds(spawnInterval);

            // Si ya se alcanzó el máximo de enemigos, no spawnear más.
            if (enemyCount >= maxEnemies)
                continue;

            // Selecciona un punto de spawn aleatorio.
            int randomIndex = Random.Range(0, spawnPoints.Length);
            Transform spawnPoint = spawnPoints[randomIndex];

            // Instancia el enemigo en el punto de spawn seleccionado.
            Instantiate(enemyPrefab, spawnPoint.position, spawnPoint.rotation);

            // Aumenta el contador de enemigos.
            enemyCount++;
        }
    }

    // Método para reducir el contador de enemigos cuando uno muere.
    public void EnemyDestroyed()
    {
        enemyCount--;
    }

}
