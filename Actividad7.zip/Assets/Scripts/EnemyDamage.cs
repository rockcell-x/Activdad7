using UnityEngine;

public class EnemyDamage : MonoBehaviour
{
    public int damageAmount = 10;  // Cantidad de daño que el enemigo inflige.
    public float damageCooldown = 1.0f;  // Tiempo entre cada daño.
    private float lastDamageTime;  // Tiempo desde el último golpe.

    // Este método se llama cuando otro objeto entra en el collider con "Is Trigger".
    private void OnTriggerStay(Collider other)
    {
        // Verifica si el objeto con el que choca el enemigo es el jugador.
        if (other.CompareTag("Player"))
        {
            // Verifica si ha pasado suficiente tiempo desde el último daño.
            if (Time.time > lastDamageTime + damageCooldown)
            {
                // Llama a la función que maneja el daño en el jugador.
                PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();
                if (playerHealth != null)
                {
                    playerHealth.TakeDamage(damageAmount);
                    lastDamageTime = Time.time;  // Actualiza el tiempo del último daño.
                }
            }
        }
    }
}
